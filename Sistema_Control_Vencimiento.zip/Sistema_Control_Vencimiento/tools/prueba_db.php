<?php
require_once __DIR__ . '/../src/conexion.php';
echo $pdo ? "Conexión OK\n" : "Sin conexión\n";
